<?php 
    $host = 'localhost';
    $user = 'root';
    $pass = '';
    $dbname = 'inventory';
    $con = mysqli_connect($host, $user, $pass, $dbname);
?>